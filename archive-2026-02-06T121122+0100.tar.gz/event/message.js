import config from "../config.js"
import { downloadContentFromMessage } from "@whiskeysockets/baileys"
import fs from "fs"
import chalk from "chalk"
import Tesseract from "tesseract.js"
import { createCanvas, loadImage, registerFont} from "canvas" 
import archiver from "archiver" // untuk menggabungkan dalam bentuk zip
// HAPUS import moment agar tidak error modul

// --- DATABASE SISTEM ---
const dbPath = './database.json'

// Cek & Bikin Database
if (!fs.existsSync(dbPath)) {
    fs.writeFileSync(dbPath, JSON.stringify({ 
        users: {}, 
        settings: {
            scan: 0,
            barcode_acak: 1000,
            filter8: 2000,
            barcode_custom: 10000,
            vip_barcode_acak: 1000, 
            vip_barcode_custom: 5000,
            android_acak: 1200,
            android_custom: 10000
        } 
    }, null, 2))
}

// --- DATABASE HISTORY (LOGGING) ---
const historyPath = './history_saldo.json'

// Buat file history jika belum ada
if (!fs.existsSync(historyPath)) {
    fs.writeFileSync(historyPath, JSON.stringify([], null, 2))
}

// Fungsi Pencatat Riwayat
const catatRiwayat = (target, tipe, nominal, saldoAkhir, pelakunya) => {
    try {
        let dataHistory = JSON.parse(fs.readFileSync(historyPath))
        
        let logBaru = {
            waktu: new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta" }),
            target_user: target.split('@')[0],
            tipe_transaksi: tipe, 
            nominal: nominal,
            saldo_akhir: saldoAkhir,
            eksekutor: pelakunya.split('@')[0]
        }
        
        dataHistory.push(logBaru)
        fs.writeFileSync(historyPath, JSON.stringify(dataHistory, null, 2))
    } catch (e) {
        console.log("Gagal mencatat history:", e)
    }
}


const getDb = () => JSON.parse(fs.readFileSync(dbPath))
const saveDb = (data) => fs.writeFileSync(dbPath, JSON.stringify(data, null, 2))

// FUNGSI JEDA (DELAY) AGAR TIDAK SPAM
const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms))

export default async function Message(hisoka, m, chatUpdate) {
    try {
        // 1. PENGAMAN
        if (!m || !m.key || !m.sender) return 
        if (m.key.fromMe && !m.body.startsWith('.')) return

        // --- DEFINISI VARIABLE (REVISI PARSING COMMAND) ---
        const prefix = config.options.prefix.test(m.body) ? m.body.match(config.options.prefix)[0] : '.'
        const isCmd = m.body.startsWith(prefix)
        
        // [FIX] Split pakai \s+ agar ENTER terbaca sebagai pemisah command
        const command = isCmd ? m.body.slice(prefix.length).trim().split(/\s+/)[0].toLowerCase() : ""
        
        const text = m.text || ""
        const pushName = m.pushName || "User"
        
        // --- LOGIKA ID USER ---
        const sender = m.sender
        const senderNum = sender.split('@')[0]
        const isOwner = config.options.owner.some(own => senderNum.includes(own)) || m.key.fromMe

        // Load Database
        const db = getDb()
        
        // Auto Register
        if (!db.users[sender]) {
            db.users[sender] = { saldo: 0, nama: pushName, vip: false } // Tambah vip: false
            saveDb(db)
        }


        // Data Global
        let HARGA = db.settings
        let userSaldo = db.users[sender].saldo

        // --- DEBUG LOG ---
        if (command) {
            console.log(chalk.cyan(`[CMD] ${command}`), chalk.yellow(`dari ${pushName} (${senderNum})`))
        }

        // --- TAMPILAN MENU ---
        const sendMenu = async () => {
            // Cek status VIP user dari database
            let isVip = db.users[sender].vip || false
            let statusUser = isVip ? "👑 VIP MEMBER" : "🆓 Free User"

            let menu = `🤖 *AIRBOT SERVICE*
👤 User: ${pushName}
🏷️ Status: ${statusUser}
💰 Saldo: Rp ${userSaldo.toLocaleString()}

🤖 *Fitur non create*
• ${prefix}scan (Reply Foto Barcode)
• ${prefix}filter8 (memilah IMEI 8 digit awal)

🏷️ *CETAK BARCODE (UI Style)*
• ${prefix}ipputih imei1|imei2
• ${prefix}ipputih imei1|imei2|eid|meid
• ${prefix}iphitam (Format Sama dengan ipputih)
• ${prefix}iphitamnew ipputihnew (UI iPhone versi baru)
• ${prefix}ipputihold iphitamold (Without Zip file)
• ${prefix}android (langsung generate dark dan light mode)

💰 *HARGA LAYANAN*
- *IPHONE*
Regular: Acak ${db.settings.barcode_acak} | Custom ${db.settings.barcode_custom}
VIP: Acak ${db.settings.vip_barcode_acak} | Custom ${db.settings.vip_barcode_custom}
- *ANDROID*
Acak: ${db.settings.android_acak}
custom: ${db.settings.android_custom}
- *filter8:* ${db.settings.filter8}

💰 *DEPOSIT / TOPUP*
• ${prefix}deposit (Metode QRIS Otomatis)

ℹ️ *INFO*
• ${prefix}saldo
• ${prefix}admin`

            if (isOwner) {
                menu += `\n\n👑 *PANEL ADMIN*
💰 *KEUANGAN*
• ${prefix}addsaldo nomor|jumlah
• ${prefix}minsaldo nomor|jumlah
• ${prefix}addvip nomor|1 (1=VIP, 0=Biasa)`
            }
            m.reply(menu)
        }


        // --- LOGIKA PERINTAH ---
        switch (command) {

            case 'menu':
            case 'help':
                await sendMenu()
                break
            
            // ==========================================
            // 💰 FITUR DEPOSIT / QRIS (BARU)
            // ==========================================
            case 'deposit':
            case 'topup':
            case 'isisaldo':
                // Pastikan file qris.jpg sudah ada di panel (Huruf kecil semua)
                try {
                    if (!fs.existsSync('./qris.jpg')) return m.reply("⚠️ *MAAF!* Admin belum upload foto QRIS (qris.jpg).")
                    
                    let qrisBuffer = fs.readFileSync('./qris.jpg')
                    await hisoka.sendMessage(m.from, { 
                        image: qrisBuffer, 
                        caption: `🏧 *METODE PEMBAYARAN*\n\nSilakan scan QRIS di atas.\n\n✅ *Support:* BCA, BRI, DANA, GOPAY, OVO, SHOPEEPAY, Dan Masih Banyak Lagi...\n\nSetelah transfer, kirim bukti transfer ke Admin:\nwa.me/6282340063171` 
                    }, { quoted: m })
                } catch (e) {
                    console.log(e)
                    m.reply("⚠️ Gagal mengirim QRIS.")
                }
                break

            // ==========================================
            // 👑 FITUR ADD SALDO (MANUAL ONLY + HISTORY)
            // ==========================================
            case 'addsaldo':
            case 'tambahsaldo':
                if (!isOwner) return m.reply("❌ Maaf, perintah ini hanya untuk Admin.")
                
                let targetUser = ""
                let nominal = 0

                // HANYA CARA MANUAL: KETIK (Contoh: .addsaldo 628xxx|5000)
                if (text.includes("|")) {
                    let [nomor, jumlah] = text.split("|")
                    nomor = nomor.replace(/[^0-9]/g, '')
                    
                    // Deteksi LID vs WA Biasa
                    if (nomor.length >= 14) {
                        targetUser = nomor + '@lid'
                    } else {
                        if(nomor.startsWith('08')) nomor = '628' + nomor.slice(2)
                        targetUser = nomor + '@s.whatsapp.net'
                    }
                    
                    nominal = parseInt(jumlah)
                } else {
                    return m.reply(`❌ *CARA PAKAI:*\nKetik perintah manual:\n*${prefix}addsaldo 628xxx|50000*`)
                }

                if (!nominal) return m.reply("❌ Nominal salah/kosong.")

                // Update Database
                if (!db.users[targetUser]) db.users[targetUser] = { saldo: 0, nama: "User Topup" }
                db.users[targetUser].saldo += nominal
                saveDb(db)
                
                // 🔥 CATAT RIWAYAT
                catatRiwayat(targetUser, "DEPOSIT (+)", nominal, db.users[targetUser].saldo, sender)
                
                // 1. LAPORAN KE OWNER
                let infoTarget = targetUser.split('@')[0]
                m.reply(`✅ *SUKSES TAMBAH SALDO*\n\n👤 User: ${infoTarget}\n💵 Masuk: Rp ${nominal.toLocaleString()}\n💰 Total Saldo: Rp ${db.users[targetUser].saldo.toLocaleString()}`)

                // 2. NOTIFIKASI KE PELANGGAN
                try {
                    await hisoka.sendMessage(targetUser, { 
                        text: `🎉 *DEPOSIT BERHASIL!*\n\nHalo Bosku! Saldo akun kamu telah ditambahkan.\n\n➕ Nominal: Rp ${nominal.toLocaleString()}\n💰 Total Saldo: Rp ${db.users[targetUser].saldo.toLocaleString()}\n\nTerima kasih sudah deposit! 🤝`
                    })
                } catch (e) {
                    m.reply("⚠️ Saldo masuk, tapi gagal kirim notif ke User.")
                }
                break

            // ==========================================
            // 💸 FITUR KURANG SALDO (MANUAL ONLY + HISTORY)
            // ==========================================
            case 'kurangsaldo':
            case 'removesaldo':
            case 'minsaldo':
                if (!isOwner) return m.reply("❌ Maaf, perintah ini hanya untuk Admin.")
                
                let targetMin = ""
                let nominalMin = 0

                // HANYA CARA MANUAL: KETIK (Contoh: .kurangsaldo 628xxx|5000)
                if (text.includes("|")) {
                    let [nomor, jumlah] = text.split("|")
                    nomor = nomor.replace(/[^0-9]/g, '')
                    
                    if (nomor.length >= 14) {
                        targetMin = nomor + '@lid'
                    } else {
                        if(nomor.startsWith('08')) nomor = '628' + nomor.slice(2)
                        targetMin = nomor + '@s.whatsapp.net'
                    }
                    
                    nominalMin = parseInt(jumlah)
                } else {
                    return m.reply(`❌ *CARA PAKAI:*\nKetik perintah manual:\n*${prefix}kurangsaldo 628xxx|50000*`)
                }

                if (!nominalMin) return m.reply("❌ Nominal salah/kosong.")

                // Cek User Database
                if (!db.users[targetMin]) return m.reply("⚠️ User belum terdaftar di database.")
                
                // EKSEKUSI PENGURANGAN
                db.users[targetMin].saldo -= nominalMin
                if (db.users[targetMin].saldo < 0) db.users[targetMin].saldo = 0
                
                saveDb(db)
                
                // 🔥 CATAT RIWAYAT
                catatRiwayat(targetMin, "POTONGAN (-)", nominalMin, db.users[targetMin].saldo, sender)
                
                // 1. LAPORAN KE OWNER
                let infoTargetMin = targetMin.split('@')[0]
                m.reply(`✅ *SUKSES KURANGI SALDO*\n\n👤 User: ${infoTargetMin}\n📉 Dikurang: Rp ${nominalMin.toLocaleString()}\n💰 Sisa Saldo: Rp ${db.users[targetMin].saldo.toLocaleString()}`)

                // 2. NOTIFIKASI KE PELANGGAN
                try {
                    await hisoka.sendMessage(targetMin, { 
                        text: `📉 *PENGURANGAN SALDO*\n\nHalo Bosku! Saldo akun kamu telah dikurangi oleh Admin.\n\n➖ Nominal: Rp ${nominalMin.toLocaleString()}\n💰 Sisa Saldo: Rp ${db.users[targetMin].saldo.toLocaleString()}`
                    })
                } catch (e) {
                    m.reply("⚠️ Saldo berkurang, tapi gagal kirim notif ke User.")
                }
                break

            case 'addvip':
                if (!isOwner) return m.reply("❌ Khusus Admin.")
                let tUser = ""
                let statusVip = false
                if (text.includes("|")) {
                    let [nomor, status] = text.split("|")
                    nomor = nomor.replace(/[^0-9]/g, '')
                    tUser = nomor.length >= 14 ? nomor + '@lid' : (nomor.startsWith('08') ? '628' + nomor.slice(2) : nomor) + '@s.whatsapp.net'
                    statusVip = (status.trim() == '1')
                } else if (m.quoted) {
                   tUser = m.quoted.sender
                   statusVip = text.trim() !== '0'
                } else {
                   return m.reply(`❌ Contoh: ${prefix}addvip 628xxx|1`)
                }
               if (!db.users[tUser]) db.users[tUser] = { saldo: 0, nama: "User VIP", vip: false }
               db.users[tUser].vip = statusVip
               saveDb(db)
               m.reply(`✅ VIP Update: ${tUser.split('@')[0]} status: ${statusVip}`)
               break

        
            case 'saldo':
            case 'balance':
                m.reply(`💳 *INFO SALDO*\nUser: ${pushName}\nSisa: Rp ${userSaldo.toLocaleString()}\nID: ${senderNum}`)
                break

            case 'scan':
                if (!isOwner && userSaldo < HARGA.scan) return m.reply(`⚠️ *SALDO KURANG!*`)
                
                const isImage = m.isMedia || (m.quoted && m.quoted.isMedia)
                if (!isImage) return m.reply(`❌ Kirim foto dengan caption *${prefix}scan*`)
                
                m.reply("⏳ Sedang memproses gambar...")
                
                try {
                    let media = m.quoted ? await m.quoted.download() : await m.download()
                    const { data: { text: hasilBaca } } = await Tesseract.recognize(media, 'eng')
                    let imeis = hasilBaca.match(/\b\d{15}\b/g)
                    
                    if (imeis) {
                        if (!isOwner) {
                            db.users[sender].saldo -= HARGA.scan
                            saveDb(db)
                        }
                        let unikImei = [...new Set(imeis)].join("\n")
                        m.reply(`🔍 *HASIL SCAN*\n\n${unikImei}\n\n💸 Terpotong: Rp ${HARGA.scan}\n💳 Sisa Saldo: Rp ${db.users[sender].saldo.toLocaleString()}`)
                    } else {
                        m.reply(`⚠️ Tidak ditemukan angka IMEI valid.`)
                    }
                } catch (e) {
                    m.reply("❌ Gagal membaca gambar.")
                }
                break

            // ==========================================
            // 📱 BARCODE UI (BATCH ZIP + CROSS DUPLICATE CHECK)
            // ==========================================
            case 'ipputih':
            case 'iphitam':
                // 1. BERSIHKAN COMMAND
                let rawBody = m.body.slice(prefix.length).trim() 
                let content = rawBody.replace(new RegExp(`^${command}`, 'i'), '').trim()
                
                if (!content) return m.reply(`❌ *FORMAT BARU!*\n\nCaranya:\n.${command}\nIMEI1\nIMEI2\nEID (Opsional)\nMEID (Opsional)\n\n*(Gunakan Double Enter jika mau bikin banyak)*`)

                // 2. SPLIT DATA
                let antrianData = content.split(/\n\s*\n/)
                
                // --- 🔥 LOGIKA BARU: DETEKSI DUPLIKAT ANTAR DATA (CROSS CHECK) ---
                let imeiTracker = {} 
                let listDuplikatTxt = [] // Isi untuk file TXT di dalam ZIP
                let infoDuplikatChat = [] // Isi untuk Caption Chat

                // Loop dulu cuma buat ngecek duplikat (Tanpa proses gambar)
                antrianData.forEach((blok, idx) => {
                    let lines = blok.split('\n').map(x => x.trim()).filter(x => x)
                    if (lines.length > 0) {
                        let keyImei = lines[0] // Kita pakai IMEI 1 sebagai patokan kembar
                        
                        if (!imeiTracker[keyImei]) {
                            imeiTracker[keyImei] = []
                        }
                        imeiTracker[keyImei].push({
                            urutan: idx + 1,
                            isi: lines.join(' | ') // Simpan format sebaris buat laporan
                        })
                    }
                })

                // Analisis hasil tracker
                Object.keys(imeiTracker).forEach(k => {
                    let group = imeiTracker[k]
                    if (group.length > 1) {
                        let urutanKembar = group.map(x => x.urutan).join(' & ')
                        
                        // 1. Buat Chat (Singkat)
                        infoDuplikatChat.push(`⚠️ Data ke-${urutanKembar}`)
                        
                        // 2. Buat TXT (Detail)
                        listDuplikatTxt.push(`[KEMBAR] Data ke-${urutanKembar}\nInput: ${group[0].isi}`)
                    }
                })
                // -------------------------------------------------------------

                let isDark = (command === 'iphitam')
                let modeText = isDark ? "GELAP (Dark)" : "TERANG (Light)"
                
                m.reply(`⏳ Mendeteksi ${antrianData.length} data. Sedang memproses & mengemas file...`)

                // Register Font
                try {
                    if (fs.existsSync('./SFPro.otf')) registerFont('./SFPro.otf', { family: 'SFNumber' })
                } catch (e) { }

                if (!fs.existsSync('./temp')) fs.mkdirSync('./temp');

                // Helper
                const loadWithTimeout = (url, ms = 10000) => {
                    return Promise.race([
                        loadImage(url),
                        new Promise((_, reject) => setTimeout(() => reject(new Error("Timeout")), ms))
                    ])
                }
                const acakAngka = (p) => {
                    let h = ''; for (let j=0; j<p; j++) h += Math.floor(Math.random()*10); return h;
                }

                // --- VARIABEL PENAMPUNG HASIL ---
                let hasilSukses = [] 
                let hasilGagal = []  
                let totalBiaya = 0   

                // --- MULAI LOOPING PEMBUATAN GAMBAR ---
                for (let i = 0; i < antrianData.length; i++) {
                    let canvas = null
                    try {
                        let blokData = antrianData[i]
                        let baris = blokData.split('\n').map(l => l.trim()).filter(l => l)

                        if (baris.length < 2) {
                            hasilGagal.push(`Data ke-${i+1} (Kurang Lengkap)`)
                            continue
                        }

                        let im1 = baris[0]; let im2 = baris[1]
                        let customEid = baris[2]; let customMeid = baris[3]

                        // Estimasi Biaya
                        let isVip = db.users[sender].vip || false
                        let hargaItem = (customEid || customMeid) ? 
                            (isVip ? HARGA.vip_barcode_custom : HARGA.barcode_custom) : 
                            (isVip ? HARGA.vip_barcode_acak : HARGA.barcode_acak)

                        if (!isOwner && (db.users[sender].saldo < (totalBiaya + hargaItem))) {
                            hasilGagal.push(`Data ke-${i+1} (Saldo Habis)`)
                            continue 
                        }

                        // Generate
                        let finalEid = customEid ? customEid.toString() : "890490320" + acakAngka(23)
                        let finalMeid = customMeid ? customMeid.toString().toUpperCase() : acakAngka(14)
                        
                        let templateFile = isDark ? './template_dark.png' : './template.png'
                        let textColor = isDark ? '#FFFFFF' : '#000000'
                        const makeUrl = (txt) => `https://bwipjs-api.metafloor.com/?bcid=code128&text=${txt}&scale=3&incltext=n&height=12`

                        const [bg, imgEID, imgIM1, imgIM2, imgMEID] = await Promise.all([
                            loadImage(templateFile),
                            loadWithTimeout(makeUrl(finalEid)),
                            loadWithTimeout(makeUrl(im1)),
                            loadWithTimeout(makeUrl(im2)),
                            loadWithTimeout(makeUrl(finalMeid))
                        ])

                        canvas = createCanvas(bg.width, bg.height)
                        const ctx = canvas.getContext('2d')

                        // DRAWING LOGIC (STANDAR IP)
                        ctx.drawImage(bg, 0, 0)
                        ctx.textAlign = 'center'
                        const nulisNomor = (teks, x, y, isJam = false) => {
                            ctx.fillStyle = textColor;
                            ctx.strokeStyle = textColor;
                            ctx.lineWidth = isJam ? 0.4 : 0.1
                            ctx.font = '18px "SFNumber", "Arial", sans-serif'
                            ctx.fillText(teks, x, y);
                            ctx.strokeText(teks, x, y)
                        }

                        let date = new Date(); date.setHours(date.getHours() + 6)
                        let waktuTampil = `${date.getHours().toString().padStart(2,'0')}:${date.getMinutes().toString().padStart(2,'0')}`
                        nulisNomor(waktuTampil, 55, 35, true)

                        const drawWhiteBox = (x, y, w, h) => { if(isDark) { ctx.fillStyle='#FFFFFF'; ctx.fillRect(x,y,w,h) } }

                        const eidW=220; const eidH=35; const eidX=(bg.width-eidW)/2
                        nulisNomor('EID', bg.width/2, 210); nulisNomor(finalEid, bg.width/2, 235)
                        drawWhiteBox(eidX, 280, eidW, eidH); ctx.drawImage(imgEID, eidX, 280, eidW, eidH)

                        const imeiW=280; const imeiH=75; const imeiX=(bg.width-imeiW)/2
                        nulisNomor(`IMEI ${im1}`, bg.width/2, 400)
                        drawWhiteBox(imeiX, 435, imeiW, imeiH); ctx.drawImage(imgIM1, imeiX, 435, imeiW, imeiH)

                        nulisNomor(`IMEI2 ${im2}`, bg.width/2, 580)
                        drawWhiteBox(imeiX, 615, imeiW, imeiH); ctx.drawImage(imgIM2, imeiX, 615, imeiW, imeiH)

                        const meidW=240; const meidH=70; const meidX=(bg.width-meidW)/2
                        nulisNomor(`MEID ${finalMeid}`, bg.width/2, 760)
                        drawWhiteBox(meidX, 795, meidW, meidH); ctx.drawImage(imgMEID, meidX, 795, meidW, meidH)

                        let namaFile = `IMG_${i+1}_${im1}.jpg`
                        let pathFile = `./temp/${namaFile}`
                        fs.writeFileSync(pathFile, canvas.toBuffer('image/jpeg'))

                        hasilSukses.push({ path: pathFile, name: namaFile })
                        totalBiaya += hargaItem

                    } catch (e) {
                        console.error(`Error data ke-${i+1}:`, e.message)
                        hasilGagal.push(`Data ke-${i+1} (Error Server)`)
                    } finally {
                        if (canvas) canvas = null
                    }
                } 

                // 3. PENGIRIMAN
                if (hasilSukses.length === 0) return m.reply(`❌ Gagal Semua.\nDetail:\n${hasilGagal.join('\n')}`)

                if (!isOwner && totalBiaya > 0) {
                    db.users[sender].saldo -= totalBiaya
                    saveDb(db)
                }

                let captionAkhir = `✅ *PROSES SELESAI*\n`
                captionAkhir += `📁 Sukses: ${hasilSukses.length}\n`
                captionAkhir += `❌ Gagal: ${hasilGagal.length}\n`
                captionAkhir += `💸 Total Bayar: Rp ${totalBiaya.toLocaleString()}\n`
                captionAkhir += `💰 Sisa Saldo: Rp ${db.users[sender].saldo.toLocaleString()}\n`
                
                if (hasilGagal.length > 0) captionAkhir += `\n⚠️ *Info Gagal:*\n${hasilGagal.join('\n')}`
                
                // 🔥 INFO DUPLIKAT DI CAPTION
                if (infoDuplikatChat.length > 0) {
                    captionAkhir += `\n⚠️ *TERDETEKSI DATA KEMBAR:*\n${infoDuplikatChat.join('\n')}\n*(Detail ada di file INFO_DUPLIKAT.txt dalam ZIP)*`
                }

                try {
                    if (antrianData.length > 1) {
                        let zipPath = `./temp/Result_${sender.split('@')[0]}_${Date.now()}.zip`
                        let output = fs.createWriteStream(zipPath)
                        let archive = archiver('zip', { zlib: { level: 9 } })

                        await new Promise((resolve, reject) => {
                            output.on('close', resolve)
                            archive.on('error', reject)
                            archive.pipe(output)
                            
                            // Masukkan gambar
                            hasilSukses.forEach(f => archive.file(f.path, { name: f.name }))
                            
                            // 🔥 MASUKKAN INFO DUPLIKAT KE DALAM ZIP (JIKA ADA)
                            if (listDuplikatTxt.length > 0) {
                                let kontenTxt = "=== LAPORAN DATA KEMBAR ===\n\n" + listDuplikatTxt.join('\n\n------------------------\n\n')
                                archive.append(kontenTxt, { name: 'INFO_DUPLIKAT.txt' })
                            }

                            archive.finalize()
                        })

                        await hisoka.sendMessage(m.from, { 
                            document: fs.readFileSync(zipPath), 
                            mimetype: 'application/zip',
                            fileName: `Barcode_Result.zip`,
                            caption: captionAkhir
                        }, { quoted: m })

                        fs.unlinkSync(zipPath)

                    } else {
                        // Jika cuma 1 gambar, kirim biasa (Caption tetap ada info duplikat jika user iseng kirim 1 data yg sama persis di history - though technically impossible if input length is 1)
                        await hisoka.sendMessage(m.from, { 
                            image: fs.readFileSync(hasilSukses[0].path), 
                            caption: captionAkhir 
                        }, { quoted: m })
                    }

                } catch (e) {
                    m.reply("❌ Gagal mengirim file.")
                    console.error(e)
                } finally {
                    hasilSukses.forEach(f => { if(fs.existsSync(f.path)) fs.unlinkSync(f.path) })
                }
                break


            // ==========================================
            // 📱 BARCODE UI NEW (IOS 17 STYLE - REALISTIC SPACING)
            // ==========================================
            case 'ipputihnew':
            case 'iphitamnew':
                // 1. BERSIHKAN COMMAND
                let rawBodyNew = m.body.slice(prefix.length).trim() 
                let contentNew = rawBodyNew.replace(new RegExp(`^${command}`, 'i'), '').trim()
                
                if (!contentNew) return m.reply(`❌ *FORMAT BARU (IOS STYLE)*\n\nCaranya:\n.${command}\nIMEI1\nIMEI2\nEID (Opsional)\nMEID (Opsional)\n\n*(Gunakan Double Enter jika mau bikin banyak)*`)

                // 2. SPLIT DATA
                let antrianNew = contentNew.split(/\n\s*\n/)
                
                // --- 🔥 LOGIKA BARU: DETEKSI DUPLIKAT CROSS CHECK (NEW UI) ---
                let imeiTrackerNew = {} 
                let listDuplikatTxtNew = [] // Isi untuk file TXT di dalam ZIP
                let infoDuplikatChatNew = [] // Isi untuk Caption Chat

                // Loop analisis duplikat
                antrianNew.forEach((blok, idx) => {
                    let lines = blok.split('\n').map(x => x.trim()).filter(x => x)
                    if (lines.length > 0) {
                        let keyImei = lines[0] // Pakai IMEI 1 sebagai patokan
                        if (!imeiTrackerNew[keyImei]) imeiTrackerNew[keyImei] = []
                        imeiTrackerNew[keyImei].push({
                            urutan: idx + 1,
                            isi: lines.join(' | ')
                        })
                    }
                })

                // Susun laporan duplikat
                Object.keys(imeiTrackerNew).forEach(k => {
                    let group = imeiTrackerNew[k]
                    if (group.length > 1) {
                        let urutanKembar = group.map(x => x.urutan).join(' & ')
                        // Info untuk Chat
                        infoDuplikatChatNew.push(`⚠️ Data ke-${urutanKembar}`)
                        // Info untuk TXT
                        listDuplikatTxtNew.push(`[KEMBAR] Data ke-${urutanKembar}\nInput: ${group[0].isi}`)
                    }
                })
                // -------------------------------------------------------------
                
                let isDarkNew = (command === 'iphitamnew')
                let modeTextNew = isDarkNew ? "GELAP (Dark New)" : "TERANG (Light New)"
                
                m.reply(`⏳ Mendeteksi ${antrianNew.length} data (${modeTextNew}). Memproses...`)

                // Register Font
                try {
                    if (fs.existsSync('./SFPro.otf')) registerFont('./SFPro.otf', { family: 'SFNumber' })
                } catch (e) { }

                if (!fs.existsSync('./temp')) fs.mkdirSync('./temp');

                // Helper Sama
                const loadTimeoutNew = (url, ms = 10000) => {
                    return Promise.race([
                        loadImage(url),
                        new Promise((_, reject) => setTimeout(() => reject(new Error("Timeout")), ms))
                    ])
                }
                const acakAngkaNew = (p) => {
                    let h = ''; for (let j=0; j<p; j++) h += Math.floor(Math.random()*10); return h;
                }

                let hasilSuksesNew = []
                let hasilGagalNew = []
                let totalBiayaNew = 0

                // --- MULAI LOOPING ---
                for (let i = 0; i < antrianNew.length; i++) {
                    let canvas = null
                    try {
                        let blokData = antrianNew[i]
                        let baris = blokData.split('\n').map(l => l.trim()).filter(l => l)

                        if (baris.length < 2) {
                            hasilGagalNew.push(`Data ke-${i+1} (Kurang Lengkap)`)
                            continue
                        }

                        let im1 = baris[0]; let im2 = baris[1]
                        let customEid = baris[2]; let customMeid = baris[3]
                        
                        // HARGA SAMA
                        let isVip = db.users[sender].vip || false
                        let hargaItem = (customEid || customMeid) ? 
                            (isVip ? HARGA.vip_barcode_custom : HARGA.barcode_custom) : 
                            (isVip ? HARGA.vip_barcode_acak : HARGA.barcode_acak)

                        if (!isOwner && (db.users[sender].saldo < (totalBiayaNew + hargaItem))) {
                            hasilGagalNew.push(`Data ke-${i+1} (Saldo Habis)`)
                            continue 
                        }

                        let finalEid = customEid ? customEid.toString() : "890490320" + acakAngkaNew(23)
                        let finalMeid = customMeid ? customMeid.toString().toUpperCase() : acakAngkaNew(14)
                        
                        // SETUP ASSETS
                        let templateFile = isDarkNew ? './template_new_dark.png' : './template_new_light.png'
                        let textColor = isDarkNew ? '#FFFFFF' : '#000000'
                        
                        // API Barcode
                        const makeUrl = (txt) => `https://bwipjs-api.metafloor.com/?bcid=code128&text=${txt}&scale=3&incltext=n&height=17`

                        const [bg, imgEID, imgIM1, imgIM2, imgMEID] = await Promise.all([
                            loadImage(templateFile),
                            loadTimeoutNew(makeUrl(finalEid)),
                            loadTimeoutNew(makeUrl(im1)),
                            loadTimeoutNew(makeUrl(im2)),
                            loadTimeoutNew(makeUrl(finalMeid))
                        ])

                        canvas = createCanvas(bg.width, bg.height)
                        const ctx = canvas.getContext('2d')

                        // 1. GAMBAR BACKGROUND
                        ctx.drawImage(bg, 0, 0)
                        
                        // 2. JAM (Time)
                        let date = new Date(); date.setHours(date.getHours() + 6) // WIB
                        let jamStr = `${date.getHours().toString().padStart(2,'0')}:${date.getMinutes().toString().padStart(2,'0')}`
                        
                        ctx.fillStyle = '#FFFFFF'; ctx.strokeStyle = '#FFFFFF';
                        ctx.lineWidth = 1 
                        ctx.font = '19px "SFNumber", "Arial", sans-serif'
                        ctx.fillText(jamStr, 40, 35) 
                        ctx.strokeText(jamStr, 40, 35)

                        // 3. SETTING GLOBAL
                        let cX = bg.width / 2 
                        
                        // 🔥 KOORDINAT AWAL
                        let currentY = 160    
                        
                        const drawWhiteBox = (x, y, w, h) => { 
                            if(isDarkNew) { ctx.fillStyle='#FFFFFF'; ctx.fillRect(x,y,w,h) } 
                        }

                        // ==========================================
                        // 🔥 FUNGSI BARU: NULIS DENGAN JARAK SPASI
                        // ==========================================
                        const nulisSpasi = (teks, y, isBold = false, jarak = 0) => {
                            ctx.fillStyle = textColor
                            
                            // Setup Font
                            if (isBold) {
                                ctx.font = '16px "SFNumber", "Arial", sans-serif' 
                                ctx.lineWidth = 0.5
                                ctx.strokeStyle = textColor
                            } else {
                                ctx.font = '16px "SFNumber", "Arial", sans-serif' 
                            }

                            if (jarak > 0) {
                                // --- LOGIKA MANUAL SPACING (BIAR CENTER) ---
                                ctx.textAlign = 'left' 
                                
                                let totalW = 0
                                for (let k=0; k<teks.length; k++) {
                                    totalW += ctx.measureText(teks[k]).width
                                    if(k < teks.length -1) totalW += jarak
                                }
                                
                                let kursorX = (bg.width - totalW) / 2
                                
                                for (let k=0; k<teks.length; k++) {
                                    let char = teks[k]
                                    if(isBold) ctx.strokeText(char, kursorX, y)
                                    ctx.fillText(char, kursorX, y)
                                    kursorX += ctx.measureText(char).width + jarak
                                }

                            } else {
                                ctx.textAlign = 'center'
                                if(isBold) ctx.strokeText(teks, cX, y)
                                ctx.fillText(teks, cX, y)
                            }
                        }

                        // ==========================================
                        // 📏 PENGATURAN UKURAN BARCODE
                        // ==========================================
                        const sizeEID = { w: 225, h: 47 }   
                        const sizeIMEI = { w: 290, h: 47 }  
                        const sizeMEID = { w: 240, h: 47 }  
                        const spasiAngka = 1  
                        const spacingSection = 62

                        // ============ MULAI GAMBAR ============
                        
                        // A. BAGIAN EID
                        nulisSpasi("EID", currentY, true, 1) 
                        currentY += 20

                        let eid1 = finalEid.substring(0, 31)
                        let eid2 = finalEid.substring(31)
                        
                        nulisSpasi(eid1, currentY, true, spasiAngka) 
                        if (eid2) {
                            currentY += 25
                            nulisSpasi(eid2, currentY, true, spasiAngka) 
                        }
                        
                        currentY += 35
                        let eidX = (bg.width - sizeEID.w) / 2 
                        drawWhiteBox(eidX - 10, currentY - 15, sizeEID.w + 20, sizeEID.h + 30) 
                        ctx.drawImage(imgEID, eidX, currentY, sizeEID.w, sizeEID.h)
                        
                        currentY += sizeEID.h + spacingSection

                        // B. BAGIAN IMEI 1
                        nulisSpasi(`IMEI ${im1}`, currentY, true, 1) 
                        currentY += 40
                        
                        let imei1X = (bg.width - sizeIMEI.w) / 2
                        drawWhiteBox(imei1X - 20, currentY - 15, sizeIMEI.w + 40, sizeIMEI.h + 30)
                        ctx.drawImage(imgIM1, imei1X, currentY, sizeIMEI.w, sizeIMEI.h)
                        
                        currentY += sizeIMEI.h + spacingSection

                        // C. BAGIAN IMEI 2
                        nulisSpasi(`IMEI2 ${im2}`, currentY, true, 1)
                        currentY += 40
                        
                        let imei2X = (bg.width - sizeIMEI.w) / 2
                        drawWhiteBox(imei2X - 20, currentY - 15, sizeIMEI.w + 40, sizeIMEI.h + 30)
                        ctx.drawImage(imgIM2, imei2X, currentY, sizeIMEI.w, sizeIMEI.h)
                        
                        currentY += sizeIMEI.h + spacingSection

                        // D. BAGIAN MEID
                        nulisSpasi(`MEID ${finalMeid}`, currentY, true, 1)
                        currentY += 40
                        
                        let meidX = (bg.width - sizeMEID.w) / 2
                        drawWhiteBox(meidX - 20, currentY - 15, sizeMEID.w + 40, sizeMEID.h + 30)
                        ctx.drawImage(imgMEID, meidX, currentY, sizeMEID.w, sizeMEID.h)


                        // --- SIMPAN ---
                        const buffer = canvas.toBuffer('image/jpeg')
                        let namaFile = `NEW_${i+1}_${im1}.jpg`
                        let pathFile = `./temp/${namaFile}`
                        fs.writeFileSync(pathFile, buffer)

                        hasilSuksesNew.push({ path: pathFile, name: namaFile })
                        totalBiayaNew += hargaItem

                    } catch (e) {
                        console.error(`Error New data ke-${i+1}:`, e.message)
                        hasilGagalNew.push(`Data ke-${i+1} (Error)`)
                    } finally { if (canvas) canvas = null }
                } // End Loop

                // 3. KIRIM & POTONG SALDO
                if (hasilSuksesNew.length === 0) return m.reply(`❌ Gagal Semua.`)

                if (!isOwner && totalBiayaNew > 0) {
                    db.users[sender].saldo -= totalBiayaNew
                    saveDb(db)
                }

                let captionNew = `✅ *STYLE BARU (IOS)*\n`
                captionNew += `📁 Sukses: ${hasilSuksesNew.length}\n`
                captionNew += `💸 Total: Rp ${totalBiayaNew.toLocaleString()}\n`
                captionNew += `💰 Sisa: Rp ${db.users[sender].saldo.toLocaleString()}`
                
                // 🔥 INFO DUPLIKAT DI CAPTION
                if (infoDuplikatChatNew.length > 0) {
                    captionNew += `\n⚠️ *TERDETEKSI DATA KEMBAR:*\n${infoDuplikatChatNew.join('\n')}\n*(Detail ada di file INFO_DUPLIKAT_NEW.txt dalam ZIP)*`
                }

                try {
                    if (antrianNew.length > 1) {
                        let zipPath = `./temp/ResultNew_${Date.now()}.zip`
                        let output = fs.createWriteStream(zipPath)
                        let archive = archiver('zip', { zlib: { level: 9 } })

                        await new Promise((resolve, reject) => {
                            output.on('close', resolve); archive.on('error', reject)
                            archive.pipe(output)
                            
                            // File Gambar
                            hasilSuksesNew.forEach(f => archive.file(f.path, { name: f.name }))
                            
                            // 🔥 MASUKKAN INFO DUPLIKAT KE DALAM ZIP (JIKA ADA)
                            if (listDuplikatTxtNew.length > 0) {
                                let kontenTxt = "=== LAPORAN DATA KEMBAR (NEW UI) ===\n\n" + listDuplikatTxtNew.join('\n\n------------------------\n\n')
                                archive.append(kontenTxt, { name: 'INFO_DUPLIKAT_NEW.txt' })
                            }
                            
                            archive.finalize()
                        })
                        await hisoka.sendMessage(m.from, { document: fs.readFileSync(zipPath), mimetype: 'application/zip', fileName: `Result_IOS.zip`, caption: captionNew }, { quoted: m })
                        fs.unlinkSync(zipPath)
                    } else {
                        await hisoka.sendMessage(m.from, { image: fs.readFileSync(hasilSuksesNew[0].path), caption: captionNew }, { quoted: m })
                    }
                } catch (e) {
                    m.reply("❌ Gagal kirim gambar.")
                } finally {
                    hasilSuksesNew.forEach(f => { if(fs.existsSync(f.path)) fs.unlinkSync(f.path) })
                }
                break


            // ==========================================
            // 🕰️ BARCODE UI OLD (SEND ONE BY ONE - NO ZIP)
            // ==========================================
            case 'ipputihold':
            case 'iphitamold':
                // 1. BERSIHKAN COMMAND
                let rawBodyOld = m.body.slice(prefix.length).trim() 
                let contentOld = rawBodyOld.replace(new RegExp(`^${command}`, 'i'), '').trim()
                
                if (!contentOld) return m.reply(`❌ *FORMAT OLD (SATU-SATU)*\n\nCaranya:\n.${command}\nIMEI1\nIMEI2\nEID (Opsional)\nMEID (Opsional)\n\n*(Bot akan mengirim gambar satu per satu)*`)

                // 2. SPLIT DATA
                let antrianOld = contentOld.split(/\n\s*\n/)
                // if (antrianOld.length > 50) return m.reply(`⚠️ Maksimal 50 data!`)
                
                // --- 🔥 LOGIKA DETEKSI DUPLIKAT (CROSS CHECK) ---
                let trackerOld = {}
                // Mapping dulu semua data sebelum diproses
                antrianOld.forEach((blok, idx) => {
                    let lines = blok.split('\n').map(x => x.trim()).filter(x => x)
                    if (lines.length > 0) {
                        let key = lines[0] // Pakai IMEI 1 sebagai patokan
                        if (!trackerOld[key]) trackerOld[key] = []
                        trackerOld[key].push(idx + 1) // Simpan nomor urut (1-based)
                    }
                })
                // ------------------------------------------------

                let isDarkOld = (command === 'iphitamold')
                let modeTextOld = isDarkOld ? "GELAP (Dark Old)" : "TERANG (Light Old)"
                
                m.reply(`⏳ Memproses ${antrianOld.length} data dengan metode kirim *Satu-per-Satu*...`)

                // Register Font
                try {
                    if (fs.existsSync('./SFPro.otf')) registerFont('./SFPro.otf', { family: 'SFNumber' })
                } catch (e) { }

                // Helper Load Image dengan Timeout
                const loadTimeoutOld = (url, ms = 10000) => {
                    return Promise.race([
                        loadImage(url),
                        new Promise((_, reject) => setTimeout(() => reject(new Error("Timeout")), ms))
                    ])
                }
                // Helper Random Angka
                const acakAngkaOld = (p) => {
                    let h = ''; for (let j=0; j<p; j++) h += Math.floor(Math.random()*10); return h;
                }

                // --- MULAI LOOPING (KIRIM LANGSUNG) ---
                for (let i = 0; i < antrianOld.length; i++) {
                    let canvas = null
                    try {
                        let blokData = antrianOld[i]
                        let baris = blokData.split('\n').map(l => l.trim()).filter(l => l)

                        // Validasi Kelengkapan
                        if (baris.length < 2) {
                            m.reply(`⚠️ Data ke-${i+1} Gagal: Minimal ada IMEI1 & IMEI2.`)
                            continue
                        }

                        let im1 = baris[0]; let im2 = baris[1]
                        let customEid = baris[2]; let customMeid = baris[3]

                        // HITUNG HARGA
                        let isVip = db.users[sender].vip || false
                        let hargaItem = (customEid || customMeid) ? 
                            (isVip ? HARGA.vip_barcode_custom : HARGA.barcode_custom) : 
                            (isVip ? HARGA.vip_barcode_acak : HARGA.barcode_acak)

                        // CEK SALDO (Cek per item karena dipotong langsung)
                        if (!isOwner && db.users[sender].saldo < hargaItem) {
                            m.reply(`⚠️ *STOP!* Saldo habis saat mau proses data ke-${i+1}.`)
                            break 
                        }

                        // GENERATE ANGKA
                        let finalEid = customEid ? customEid.toString() : "890490320" + acakAngkaOld(23)
                        let finalMeid = customMeid ? customMeid.toString().toUpperCase() : acakAngkaOld(14)
                        
                        // SETUP ASSETS
                        let templateFile = isDarkOld ? './template_dark.png' : './template.png'
                        let textColor = isDarkOld ? '#FFFFFF' : '#000000'
                        const makeUrl = (txt) => `https://bwipjs-api.metafloor.com/?bcid=code128&text=${txt}&scale=3&incltext=n&height=12`

                        // LOAD GAMBAR
                        const [bg, imgEID, imgIM1, imgIM2, imgMEID] = await Promise.all([
                            loadImage(templateFile),
                            loadTimeoutOld(makeUrl(finalEid)),
                            loadTimeoutOld(makeUrl(im1)),
                            loadTimeoutOld(makeUrl(im2)),
                            loadTimeoutOld(makeUrl(finalMeid))
                        ])

                        canvas = createCanvas(bg.width, bg.height)
                        const ctx = canvas.getContext('2d')

                        // GAMBAR CANVAS (Style Standar)
                        ctx.drawImage(bg, 0, 0)
                        ctx.textAlign = 'center'
                        
                        const nulisNomor = (teks, x, y, isJam = false) => {
                            ctx.fillStyle = textColor; ctx.strokeStyle = textColor;
                            ctx.lineWidth = isJam ? 0.4 : 0.1
                            ctx.font = '18px "SFNumber", "Arial", sans-serif'
                            ctx.fillText(teks, x, y); ctx.strokeText(teks, x, y)
                        }

                        // JAM WIB
                        let date = new Date(); date.setHours(date.getHours() + 6) // Sesuaikan Timezone Server
                        let waktuTampil = `${date.getHours().toString().padStart(2,'0')}:${date.getMinutes().toString().padStart(2,'0')}`
                        nulisNomor(waktuTampil, 55, 35, true)

                        const drawWhiteBox = (x, y, w, h) => { if(isDarkOld) { ctx.fillStyle='#FFFFFF'; ctx.fillRect(x,y,w,h) } }

                        // KOORDINAT (Standar IP)
                        const eidW=220; const eidH=35; const eidX=(bg.width-eidW)/2
                        nulisNomor('EID', bg.width/2, 210); nulisNomor(finalEid, bg.width/2, 235)
                        drawWhiteBox(eidX, 280, eidW, eidH); ctx.drawImage(imgEID, eidX, 280, eidW, eidH)

                        const imeiW=280; const imeiH=75; const imeiX=(bg.width-imeiW)/2
                        nulisNomor(`IMEI ${im1}`, bg.width/2, 400)
                        drawWhiteBox(imeiX, 435, imeiW, imeiH); ctx.drawImage(imgIM1, imeiX, 435, imeiW, imeiH)

                        nulisNomor(`IMEI2 ${im2}`, bg.width/2, 580)
                        drawWhiteBox(imeiX, 615, imeiW, imeiH); ctx.drawImage(imgIM2, imeiX, 615, imeiW, imeiH)

                        const meidW=240; const meidH=70; const meidX=(bg.width-meidW)/2
                        nulisNomor(`MEID ${finalMeid}`, bg.width/2, 760)
                        drawWhiteBox(meidX, 795, meidW, meidH); ctx.drawImage(imgMEID, meidX, 795, meidW, meidH)

                        // BUAT BUFFER
                        const buffer = canvas.toBuffer('image/jpeg')

                        // --- PROSES TRANSAKSI (PER ITEM) ---
                        if (!isOwner) {
                            db.users[sender].saldo -= hargaItem
                            saveDb(db)
                        }

                        // --- CEK APAKAH DUPLIKAT? ---
                        let warningText = ""
                        // Cek tracker yang sudah dibuat di awal
                        if (trackerOld[im1] && trackerOld[im1].length > 1) {
                            let listKembar = trackerOld[im1].join(' & ')
                            warningText = `\n⚠️ *DATA DUPLIKAT!* (Sama dengan Data ke-${listKembar})`
                        }

                        // --- KIRIM LANGSUNG (NO ZIP) ---
                        await hisoka.sendMessage(m.from, { 
                            image: buffer, 
                            // REVISI CAPTION LENGKAP + WARNING DUPLIKAT
                            caption: `✅ *DATA ${i+1}/${antrianOld.length}* (${modeTextOld})\n\nIMEI 1: ${im1}\nIMEI 2: ${im2}\nEID: ${finalEid}\nMEID: ${finalMeid}${warningText}\n\n💸 Biaya: Rp ${hargaItem.toLocaleString()}\n💰 Sisa Saldo: Rp ${db.users[sender].saldo.toLocaleString()}`
                        }, { quoted: m })


                        // JEDA SEDIKIT (Biar gak dianggap spam oleh WA)
                        if (i < antrianOld.length - 1) await sleep(1500) // Jeda 1.5 detik

                    } catch (e) {
                        console.error(`Error Old data ke-${i+1}:`, e.message)
                        m.reply(`❌ Gagal data ke-${i+1}: ${e.message}`)
                    } finally {
                        if (canvas) canvas = null
                    }
                } // End Loop
                
                m.reply("✅ *Antrian Selesai!*")
                break



            // ==========================================
            // 🤖 ANDROID UI (DUAL FONT & CROSS CHECK DUPLICATE)
            // ==========================================
            case 'android':
                // 1. BERSIHKAN COMMAND
                let rawBodyAnd = m.body.slice(prefix.length).trim() 
                let contentAnd = rawBodyAnd.replace(new RegExp(`^${command}`, 'i'), '').trim()
                
                if (!contentAnd) return m.reply(`❌ *FORMAT ANDROID*\n\nCaranya:\n.${command}\nIMEI1\nIMEI2\nEID (Opsional)\nSN (Opsional)\n\n*(Bot otomatis cek template Light/Dark yang tersedia)*`)

                // 2. SPLIT DATA
                let antrianAnd = contentAnd.split(/\n\s*\n/)
                
                // --- 🔥 LOGIKA DETEKSI DUPLIKAT CROSS CHECK (ANDROID) ---
                let imeiTrackerAnd = {} 
                let listDuplikatTxtAnd = [] // Isi TXT dalam ZIP
                let infoDuplikatChatAnd = [] // Isi Caption Chat

                antrianAnd.forEach((blok, idx) => {
                    let lines = blok.split('\n').map(x => x.trim()).filter(x => x)
                    if (lines.length > 0) {
                        let keyImei = lines[0] // Pakai IMEI 1 sebagai ID unik
                        if (!imeiTrackerAnd[keyImei]) imeiTrackerAnd[keyImei] = []
                        imeiTrackerAnd[keyImei].push({
                            urutan: idx + 1,
                            isi: lines.join(' | ')
                        })
                    }
                })

                Object.keys(imeiTrackerAnd).forEach(k => {
                    let group = imeiTrackerAnd[k]
                    if (group.length > 1) {
                        let urutanKembar = group.map(x => x.urutan).join(' & ')
                        infoDuplikatChatAnd.push(`⚠️ Data ke-${urutanKembar}`)
                        listDuplikatTxtAnd.push(`[KEMBAR] Data ke-${urutanKembar}\nInput: ${group[0].isi}`)
                    }
                })
                // --------------------------------------------------------

                m.reply(`⏳ Memproses ${antrianAnd.length} data...`)

                // --- REGISTER DUA FONT BERBEDA ---
                try {
                    let pathRoboto = "./Roboto-Regular.ttf"
                    if (fs.existsSync(pathRoboto)) {
                        registerFont(pathRoboto, { family: "Roboto" })
                        console.log("✅ Font Roboto berhasil dimuat!")
                    } else {
                        console.log("❌ GAGAL: File Roboto-Regular.ttf tidak ditemukan di folder bot!")
                    }
                    if (fs.existsSync('./Roboto-Light.ttf')) {
                        registerFont('./Roboto-Light.ttf', { family: 'RobotoLight' })
                    } else { console.log("⚠️ Roboto-Light.ttf tidak ada!") }
                } catch (e) { 
                    console.log("❌ Error System Font:", e)
                }

                if (!fs.existsSync('./temp')) fs.mkdirSync('./temp');

                // HELPER KHUSUS
                const loadTimeoutAnd = (url, ms = 15000) => {
                    return Promise.race([
                        loadImage(url),
                        new Promise((_, reject) => setTimeout(() => reject(new Error("Timeout Barcode")), ms))
                    ])
                }
                const acakAngkaAnd = (p) => {
                    let h = ''; for (let j=0; j<p; j++) h += Math.floor(Math.random()*10); return h;
                }
                const acakSN = (length) => {
                    let result = '';
                    let characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
                    for (let i = 0; i < length; i++) {
                        result += characters.charAt(Math.floor(Math.random() * characters.length));
                    }
                    return result;
                }

                let hasilSuksesAnd = []
                let hasilGagalAnd = []
                let totalBiayaAnd = 0

                // --- MULAI LOOPING ---
                for (let i = 0; i < antrianAnd.length; i++) {
                    let canvas = null
                    try {
                        let blokData = antrianAnd[i]
                        let baris = blokData.split('\n').map(l => l.trim()).filter(l => l)

                        if (baris.length < 2) {
                            hasilGagalAnd.push(`Data ke-${i+1} (Kurang Lengkap)`)
                            continue
                        }

                        let im1 = baris[0]; let im2 = baris[1]
                        let customEid = baris[2]; let customSN = baris[3]; 

                        let isCustomRequest = (customEid || customSN)
                        let hargaItem = isCustomRequest ? HARGA.android_custom : HARGA.android_acak

                        if (!isOwner && (db.users[sender].saldo < (totalBiayaAnd + hargaItem))) {
                            hasilGagalAnd.push(`Data ke-${i+1} (Saldo Habis)`)
                            continue 
                        }

                        // GENERATE DATA
                        let finalEid = customEid ? customEid.toString() : "890490320" + acakAngkaAnd(23)
                        let finalSN = customSN ? customSN.toString().toUpperCase() : acakSN(11)
                        
                        const makeUrlAnd = (txt) => `https://bwipjs-api.metafloor.com/?bcid=code128&text=${txt}&scale=4&incltext=n&height=22`

                        const [bcIM1, bcIM2, bcEID, bcSN] = await Promise.all([
                            loadTimeoutAnd(makeUrlAnd(im1)),
                            loadTimeoutAnd(makeUrlAnd(im2)),
                            loadTimeoutAnd(makeUrlAnd(finalEid)),
                            loadTimeoutAnd(makeUrlAnd(finalSN))
                        ])

                        // ====================================================================
                        // 🌞 PROSES 1: LIGHT MODE (Pakai Roboto Medium)
                        // ====================================================================
                        if (fs.existsSync('./android_light.png')) {
                            let bgLight = await loadImage('./android_light.png')
                            let canvasL = createCanvas(bgLight.width, bgLight.height)
                            let ctxL = canvasL.getContext('2d')
                            ctxL.drawImage(bgLight, 0, 0)

                            // SETTING FONT LIGHT
                            let colorTextL = '#b0b3bb' 
                            ctxL.font = '38px "Roboto"' 
                            ctxL.fillStyle = colorTextL
                            ctxL.textAlign = 'left' 

                            // === UKURAN BARCODE LIGHT ===
                            let size_L_IM1 = { w: 670, h: 107 } 
                            let imei1_Txt_X = 120; let imei1_Txt_Y = 633; let imei1_Bc_Y = 675;
                            let im1_X = (bgLight.width - size_L_IM1.w) / 2

                            ctxL.fillText(`${im1} / 00`, imei1_Txt_X, imei1_Txt_Y)
                            ctxL.drawImage(bcIM1, im1_X, imei1_Bc_Y, size_L_IM1.w, size_L_IM1.h)

                            // ICCID
                            let size_L_ICC = { w: 730, h: 107 }
                            let iccid_Txt_X = 120; let iccid_Txt_Y = 985; let iccid_Bc_Y = 1026;
                            let icc_X = (bgLight.width - size_L_ICC.w) / 2
                            ctxL.fillText(finalEid, iccid_Txt_X, iccid_Txt_Y)
                            ctxL.drawImage(bcEID, icc_X, iccid_Bc_Y, size_L_ICC.w, size_L_ICC.h)

                            // IMEI 2
                            let size_L_IM2 = { w: 670, h: 107 }
                            let imei2_Txt_X = 120; let imei2_Txt_Y = 1337; let imei2_Bc_Y = 1377;
                            let im2_X = (bgLight.width - size_L_IM2.w) / 2
                            ctxL.fillText(`${im2} / 00`, imei2_Txt_X, imei2_Txt_Y)
                            ctxL.drawImage(bcIM2, im2_X, imei2_Bc_Y, size_L_IM2.w, size_L_IM2.h)

                            // SN
                            let size_L_SN = { w: 560, h: 107 }
                            let sn_Txt_X = 120; let sn_Txt_Y = 1694; let sn_Bc_Y = 1732;
                            let sn_X = (bgLight.width - size_L_SN.w) / 2
                            ctxL.fillText(finalSN, sn_Txt_X, sn_Txt_Y)
                            ctxL.drawImage(bcSN, sn_X, sn_Bc_Y, size_L_SN.w, size_L_SN.h)

                            let nameL = `Light_${i+1}_${im1}.jpg`
                            fs.writeFileSync(`./temp/${nameL}`, canvasL.toBuffer('image/jpeg'))
                            hasilSuksesAnd.push({ path: `./temp/${nameL}`, name: nameL })
                        } 

                        // ====================================================================
                        // 🌑 PROSES 2: DARK MODE (Pakai Roboto Light - Lebih Tipis)
                        // ====================================================================
                        if (fs.existsSync('./android_dark.png')) {
                            let bgDark = await loadImage('./android_dark.png')
                            let canvasD = createCanvas(bgDark.width, bgDark.height)
                            let ctxD = canvasD.getContext('2d')
                            ctxD.drawImage(bgDark, 0, 0)

                            // SETTING FONT DARK
                            let colorTextD = '#FFFFFF' 
                            ctxD.font = '38px "RobotoLight"' 
                            ctxD.fillStyle = colorTextD
                            ctxD.textAlign = 'left' 
                            
                            // IMEI 1
                            let size_D_IM1 = { w: 650, h: 201 } 
                            let d_imei1_Txt_X = 95; let d_imei1_Txt_Y = 740; let d_imei1_Bc_Y = 777;
                            let im1_X_D = (bgDark.width - size_D_IM1.w) / 2
                            ctxD.fillText(`${im1} / 01`, d_imei1_Txt_X, d_imei1_Txt_Y)
                            ctxD.drawImage(bcIM1, im1_X_D, d_imei1_Bc_Y, size_D_IM1.w, size_D_IM1.h)

                            // IMEI 2
                            let size_D_IM2 = { w: 650, h: 201 } 
                            let d_imei2_Txt_X = 95; let d_imei2_Txt_Y = 1095; let d_imei2_Bc_Y = 1134;
                            let im2_X_D = (bgDark.width - size_D_IM2.w) / 2
                            ctxD.fillText(`${im2} / 01`, d_imei2_Txt_X, d_imei2_Txt_Y)
                            ctxD.drawImage(bcIM2, im2_X_D, d_imei2_Bc_Y, size_D_IM2.w, size_D_IM2.h)

                            // EID
                            let size_D_EID = { w: 700, h: 200 } 
                            let d_eid_Txt_X = 95; let d_eid_Txt_Y = 1453; let d_eid_Bc_Y = 1491;
                            let eid_X_D = (bgDark.width - size_D_EID.w) / 2
                            ctxD.fillText(finalEid, d_eid_Txt_X, d_eid_Txt_Y)
                            ctxD.drawImage(bcEID, eid_X_D, d_eid_Bc_Y, size_D_EID.w, size_D_EID.h)

                            // SN
                            let size_D_SN = { w: 650, h: 201 } 
                            let d_sn_Txt_X = 95; let d_sn_Txt_Y = 1813; let d_sn_Bc_Y = 1845;
                            let sn_X_D = (bgDark.width - size_D_SN.w) / 2
                            ctxD.fillText(finalSN, d_sn_Txt_X, d_sn_Txt_Y)
                            ctxD.drawImage(bcSN, sn_X_D, d_sn_Bc_Y, size_D_SN.w, size_D_SN.h)

                            let nameD = `Dark_${i+1}_${im1}.jpg`
                            fs.writeFileSync(`./temp/${nameD}`, canvasD.toBuffer('image/jpeg'))
                            hasilSuksesAnd.push({ path: `./temp/${nameD}`, name: nameD })
                        }

                        if (hasilSuksesAnd.length > 0) totalBiayaAnd += hargaItem

                    } catch (e) {
                        console.error(`Error Android data ke-${i+1}:`, e.message)
                        hasilGagalAnd.push(`Data ke-${i+1} (Error)`)
                    } finally { 
                        if (canvas) canvas = null 
                    }
                } // End Loop
                
                if (hasilSuksesAnd.length === 0) return m.reply(`❌ Gagal Semua. (Cek apa template android_light.png / android_dark.png ada?)`)

                if (!isOwner && totalBiayaAnd > 0) {
                    db.users[sender].saldo -= totalBiayaAnd
                    saveDb(db)
                }

                let captionAnd = `✅ *ANDROID UI (HD)*\n`
                captionAnd += `📁 Sukses: ${hasilSuksesAnd.length} file\n`
                captionAnd += `❌ Gagal: ${hasilGagalAnd.length} data\n`
                captionAnd += `💸 Total: Rp ${totalBiayaAnd.toLocaleString()}\n`
                captionAnd += `💰 Sisa: Rp ${db.users[sender].saldo.toLocaleString()}`
                
                // 🔥 INFO DUPLIKAT DI CAPTION
                if (infoDuplikatChatAnd.length > 0) {
                    captionAnd += `\n⚠️ *TERDETEKSI DATA KEMBAR:*\n${infoDuplikatChatAnd.join('\n')}\n*(Detail ada di file INFO_DUPLIKAT_ANDROID.txt dalam ZIP)*`
                }

                try {
                    if (hasilSuksesAnd.length === 1) {
                        await hisoka.sendMessage(m.from, { 
                            image: fs.readFileSync(hasilSuksesAnd[0].path), 
                            caption: captionAnd 
                        }, { quoted: m })
                        fs.unlinkSync(hasilSuksesAnd[0].path)
                    } else {
                        let zipPath = `./temp/Android_${Date.now()}.zip`
                        let output = fs.createWriteStream(zipPath)
                        let archive = archiver('zip', { zlib: { level: 9 } })

                        await new Promise((resolve, reject) => {
                            output.on('close', resolve); archive.on('error', reject)
                            archive.pipe(output)
                            
                            // File Gambar
                            hasilSuksesAnd.forEach(f => archive.file(f.path, { name: f.name }))
                            
                            // 🔥 MASUKKAN INFO DUPLIKAT KE DALAM ZIP (JIKA ADA)
                            if (listDuplikatTxtAnd.length > 0) {
                                let kontenTxt = "=== LAPORAN DATA KEMBAR (ANDROID) ===\n\n" + listDuplikatTxtAnd.join('\n\n------------------------\n\n')
                                archive.append(kontenTxt, { name: 'INFO_DUPLIKAT_ANDROID.txt' })
                            }

                            archive.finalize()
                        })
                        
                        await hisoka.sendMessage(m.from, { document: fs.readFileSync(zipPath), mimetype: 'application/zip', fileName: `Android_Result_HD.zip`, caption: captionAnd }, { quoted: m })
                        fs.unlinkSync(zipPath)
                        hasilSuksesAnd.forEach(f => { if(fs.existsSync(f.path)) fs.unlinkSync(f.path) })
                    }
                } catch (e) {
                    m.reply("❌ Gagal kirim file.")
                    console.error(e)
                }
                break


            // ==========================================
            // 🔍 FITUR FILTER 8 DIGIT (BERBAYAR 2K)
            // ==========================================
            case 'filter8':
                const HARGA_FILTER = 2000 // Tarif 2k per request

                // 1. CEK SALDO DULU
                if (!isOwner && db.users[sender].saldo < HARGA_FILTER) {
                    return m.reply(`⚠️ *SALDO TIDAK CUKUP!*\n❌ Butuh: Rp ${HARGA_FILTER.toLocaleString()}\n💰 Saldo Kamu: Rp ${db.users[sender].saldo.toLocaleString()}`)
                }

                // 2. Ambil Data Teks
                let textFilter = m.body.slice(prefix.length + command.length).trim()
                if (!textFilter) return m.reply(`❌ *FORMAT SALAH*\n\nMasukkan daftar IMEI yang mau difilter.\nContoh:\n${prefix}filter8\n3567890122222\n3567890133333`)

                m.reply("⏳ Sedang menyortir...")

                // 3. Bersihkan & Split Data
                let listImei = textFilter.split(/\n+/).map(x => x.trim()).filter(x => x.length >= 8 && /^\d+$/.test(x))

                if (listImei.length === 0) return m.reply("❌ Tidak ada data IMEI valid yang ditemukan.")

                // 4. Logic Grouping
                let groups = {}
                listImei.forEach(imei => {
                    let prefix8 = imei.substring(0, 8)
                    if (!groups[prefix8]) groups[prefix8] = []
                    groups[prefix8].push(imei)
                })

                let twins = []   // Untuk yang punya kembaran
                let singles = [] // Untuk yang jomblo
                let sortedPrefixes = Object.keys(groups).sort()

                sortedPrefixes.forEach(p => {
                    let anggota = groups[p]
                    // Sorting digit kecil di atas
                    anggota.sort((a, b) => a.localeCompare(b, 'numeric')) 
                    
                    if (anggota.length > 1) {
                        twins.push(anggota.join('\n')) 
                    } else {
                        singles.push(anggota[0])
                    }
                })

                // 5. EKSEKUSI POTONG SALDO
                if (!isOwner) {
                    db.users[sender].saldo -= HARGA_FILTER
                    saveDb(db)
                }

                // 6. KIRIM HASIL 1: YANG KEMBAR (TWINS)
                if (twins.length > 0) {
                    let messageTwins = `✅ *HASIL FILTER 8 DIGIT (KEMBAR)*\n`
                    messageTwins += `💸 Terpotong: Rp ${HARGA_FILTER.toLocaleString()}\n`
                    messageTwins += `💰 Sisa Saldo: Rp ${db.users[sender].saldo.toLocaleString()}\n\n`
                    
                    messageTwins += twins.join('\n\n') 

                    await hisoka.sendMessage(m.from, { text: messageTwins }, { quoted: m })
                } 

                // 7. KIRIM HASIL 2: YANG SENDIRI (SINGLES)
                if (singles.length > 0) {
                    if (twins.length > 0) await sleep(1000) // Jeda dikit biar gak balapan
                    
                    let messageSingles = `⚠️ *IMEI TANPA KEMBARAN*\n`
                    // Kalau twins kosong, info saldo ditaruh di sini (biar user tau tetep bayar)
                    if (twins.length === 0) {
                        messageSingles += `💸 Terpotong: Rp ${HARGA_FILTER.toLocaleString()}\n`
                        messageSingles += `💰 Sisa Saldo: Rp ${db.users[sender].saldo.toLocaleString()}\n\n`
                    } else {
                        messageSingles += `(Sisa saldo cek di chat atas)\n\n`
                    }
                    
                    messageSingles += singles.join('\n')
                    await hisoka.sendMessage(m.from, { text: messageSingles }, { quoted: m })
                }
                break





            case 'admin':
                m.reply(`Hubungi Admin: wa.me/6289523261157`)
                break

            default:
                // Diam
        }
    } catch (e) {
        console.error("Error Message.js:", e)
    }
}
