// AIRBOT CONFIGURATION (PRO VERSION)
// Fokus: Settings, Multi-Owner, & API Management
// Updated by Wisnu for AirBot

import fs from 'fs'
import { watchFile, unwatchFile } from 'fs'
import { fileURLToPath } from 'url'

export default {
   // API Key Provider (Siapkan slotnya biar nanti tinggal isi)
   APIs: {
      sickw: {
         baseURL: 'https://sickw.com/api.php',
         Key: "APIKEY_LU_DISINI" // Nanti diisi kalau mau fitur premium check
      }
   },

   // PENGATURAN BOT
   options: {
      public: true,      // true = Mode Publik (Semua orang bisa pakai)
      antiCall: true,    // true = Auto Reject kalau ada yang nelpon WA
      database: "database.json", 
      
      // DAFTAR OWNER (User VIP) ⚠️
      // Format: String angka "628xxx"
      owner: [
          "13340554342579", // nomor kikik
          "194128394625218"  // Wizn masih salah
          // "6281334646182"
      ], 
      
      sessionName: "session", 
      // Prefix: Bot akan merespon simbol-simbol ini
      prefix: /^[./!#]/,
      
      // NOMOR BOT (Untuk Auto Pairing di Console)
      pairingNumber: "" 
   },

   // IDENTITAS STICKER (Metadata Exif)
   // Kalau user bikin stiker, info ini yang muncul di "Info Stiker"
   Exif: {
      packId: "https://airbot.id",
      packName: `AirBot Service`,
      packPublish: "Scan & Barcode Solution",
      packEmail: "admin@airbot.id",
      packWebsite: "https://airbot.id",
      androidApp: "https://play.google.com/store/apps/details?id=com.whatsapp",
      iOSApp: "https://apps.apple.com/app/whatsapp-messenger/id310633997",
      emojis: [],
      isAvatar: 0,
   },

   // PESAN RESPON DEFAULT (Auto Reply)
   msg: {
      owner: "⚠️ Maaf, fitur ini KHUSUS OWNER (Kikik/Wizn)!",
      group: "⚠️ Fitur ini hanya bisa dipakai di Grup!",
      private: "⚠️ Fitur ini hanya bisa dipakai di Chat Pribadi!",
      botAdmin: "⚠️ Bot harus jadi Admin Grup dulu!",
      admin: "⚠️ Kamu harus jadi Admin Grup dulu!",
      wait: "⏳ Sedang memproses... Mohon tunggu sebentar.",
      done: "✅ Selesai!",
      error: "❌ Terjadi kesalahan sistem. Coba lagi nanti.",
   }
}

// --- LOGIKA HOT RELOAD ---
// Biar kalau edit file ini, gak perlu restart bot
const file = fileURLToPath(import.meta.url)
watchFile(file, () => {
   unwatchFile(file)
   console.log(`Update Config: '${file}'`)
   import(`${file}?update=${Date.now()}`)
})
