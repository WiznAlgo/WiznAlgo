// AIRBOT SYSTEM LAUNCHER (HIGH PERFORMANCE)
// Created by Wizn
// Fungsi: Auto-Restart & Memory Management (4GB Allocated)

console.log('🕒 Memuat System AirBot...')

import { spawn } from "child_process"
import path from "path"
import { fileURLToPath } from "url"
import { platform } from "os"
import { watchFile, unwatchFile } from "fs"
import chalk from "chalk"

const __dirname = path.dirname(fileURLToPath(import.meta.url))

var isRunning = false

function start(file) {
   if (isRunning) return
   isRunning = true
   
   console.log(chalk.green('✅ SYSTEM STARTING...'))
   console.log(chalk.cyan('🧠 Memory Limit: 4GB (HIGH PERFORMANCE MODE)'))

   // --- RAHASIA RAM UNLIMITED (MONSTER MODE) ---
   // Pilih salah satu opsi memori di bawah ini (hapus tanda // di depan kode untuk mengaktifkan):
   
   // OPSI 1: RAM 2GB (Ringan)
   // let args = ['--max-old-space-size=2048', path.join(__dirname, file), ...process.argv.slice(2)]
   
   // OPSI 2: RAM 3GB (Medium)
   let args = ['--max-old-space-size=3072', path.join(__dirname, file), ...process.argv.slice(2)]

   // OPSI 3: RAM 4GB (High Performance - AKTIF SAAT INI)
   // let args = ['--max-old-space-size=4096', path.join(__dirname, file), ...process.argv.slice(2)]
   
   let p = spawn(process.argv[0], args, { 
       stdio: ["inherit", "inherit", "inherit", "ipc"] 
   })

   // --- HANDLER PESAN DARI SYSTEM ---
   p.on("message", (data) => {
      // console.log("[RECEIVED]", data) // Dimatikan biar gak nyepam console
      switch (data) {
         case "reset":
            platform() === "win32" ? p.kill("SIGINT") : p.kill()
            isRunning = false
            start.apply(this, arguments)
            break
         case "uptime":
            p.send(process.uptime())
            break
      }
   })

   // --- AUTO RESTART SYSTEM (ANTI MATI) ---
   p.on("exit", (code) => {
      isRunning = false
      console.error(chalk.red("❌ Bot Berhenti dengan kode:", code))
      
      if (code === 0) return // Kalau mati sengaja (Stop manual), jangan hidup lagi
      
      console.log(chalk.yellow("🔄 Merestart Bot otomatis dalam 3 detik..."))
      setTimeout(() => {
          watchFile(args[0], () => {
             unwatchFile(args[0])
          })
          start(file)
      }, 3000)
   })
}

// JALANKAN MESIN UTAMA
start("hisoka.js")
