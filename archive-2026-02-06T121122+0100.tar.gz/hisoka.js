// AIRBOT MAIN SYSTEM (FINAL FIX)
// Fitur: Only Chat, Auto-Reset Bad Session

import config from "./config.js" 
import { Client, Serialize } from "./lib/serialize.js" 
import baileys from "@whiskeysockets/baileys"
const { useMultiFileAuthState, DisconnectReason, makeInMemoryStore, makeCacheableSignalKeyStore } = baileys
import { Boom } from "@hapi/boom"
import Pino from "pino"
import chalk from "chalk"
import fs from "fs" // <--- (BARU) Library untuk hapus folder

// Logger Silent (Biar Console Bersih)
const store = makeInMemoryStore({ logger: Pino({ level: "silent" }).child({ level: "silent" }) })

async function start() {
   // Error Handler
   process.on("unhandledRejection", (err) => console.log('Silently handling error:', err.message))

   const { state, saveCreds } = await useMultiFileAuthState(`./${config.options.sessionName}`)

   const hisoka = baileys.default({
      logger: Pino({ level: "silent" }),
      printQRInTerminal: !config.options.pairingNumber,
      auth: {
         creds: state.creds,
         keys: makeCacheableSignalKeyStore(state.keys, Pino({ level: "silent" })),
      },
      browser: ['AirBot', 'Chrome', '20.0.04'],
      markOnlineOnConnect: true,
      generateHighQualityLinkPreview: true,
      defaultQueryTimeoutMs: 0,
   })

   store.bind(hisoka.ev)
   await Client({ hisoka, store })

   // Pairing Code Log
   if (config.options.pairingNumber && !hisoka.authState.creds.registered) {
      console.log(chalk.yellow("⏳ Menunggu Pairing Code..."))
      setTimeout(async () => {
         let phoneNumber = config.options.pairingNumber.replace(/[^0-9]/g, '')
         try {
            let code = await hisoka.requestPairingCode(phoneNumber)
            code = code?.match(/.{1,4}/g)?.join("-") || code
            console.log(chalk.black(chalk.bgGreen(` KODE PAIRING ANDA : `)), chalk.black(chalk.bgWhite(` ${code} `)))
         } catch (err) {
            console.log(chalk.bgRed(" ❌ Gagal minta Pairing Code. Cek nomor di config.js! "))
         }
      }, 3000)
   }

   // Koneksi Handler (VERSI AMAN + SMART LID DETECTOR)
   hisoka.ev.on("connection.update", async (update) => {
      const { lastDisconnect, connection } = update
      if (connection === "close") {
         let reason = new Boom(lastDisconnect?.error)?.output.statusCode
         
         // 1. JIKA LOGOUT DARI HP -> HAPUS SESI
         if (reason === DisconnectReason.loggedOut) {
             console.log(chalk.red(`❌ PERANGKAT DI-LOGOUT. Menghapus sesi...`))
             try {
                 fs.rmSync(`./${config.options.sessionName}`, { recursive: true, force: true })
                 console.log(chalk.green(`✅ Sesi dihapus. Silakan scan ulang.`))
             } catch (err) { console.error("Gagal hapus session:", err) }
             process.exit()
         } 
         
         // 2. JIKA BAD SESSION -> RESTART AJA (JANGAN HAPUS)
         else if (reason === DisconnectReason.badSession) {
             console.log(chalk.red(`⚠️ SESI BURUK (Bad MAC). Restarting...`))
             start() 
         } 
         
         // 3. LAIN-LAIN
         else if (reason === DisconnectReason.connectionClosed) { start() }
         else if (reason === DisconnectReason.connectionLost) { start() }
         else if (reason === DisconnectReason.restartRequired) { start() }
         else if (reason === DisconnectReason.timedOut) { start() }
         else {
            console.log(chalk.yellow(`⚠️ Disconnect reason: ${reason}`))
            start()
         }

      } else if (connection === "open") {
         console.log(chalk.green("✅ AIRBOT BERHASIL TERHUBUNG! 🚀"))
         
         // --- FITUR LAPOR OWNER (AUTO DETECT LID/WA) ---
         try {
             let rawOwner = config.options.owner[0].toString()
             let cleanNum = rawOwner.replace(/[^0-9]/g, '') // Ambil angkanya saja
             
             let targetJid = ""
             
             // REVISI USER: Batas 14 Digit
             // < 14 digit = Nomor WA Biasa
             // >= 14 digit = LID (Linked Device ID)
             if (cleanNum.length >= 14) {
                 targetJid = cleanNum + "@lid"
             } else {
                 targetJid = cleanNum + "@s.whatsapp.net"
             }

             // Kirim Laporan
             await hisoka.sendMessage(targetJid, { text: "✅ *AIRBOT ONLINE*\n\nSiap menerima perintah, Bos!" })
         } catch (e) {
             console.log("⚠️ Gagal lapor owner.")
         }
      }
   })

   hisoka.ev.on("creds.update", saveCreds)

   // Message Handler (FILTER STATUS)
   hisoka.ev.on("messages.upsert", async (message) => {
      if (!message.messages) return
      const msgRaw = message.messages[0]

      // 🛑 JANGAN BACA STATUS WA ORANG LAIN
      if (msgRaw.key.remoteJid === "status@broadcast") return
      
      // 🛑 JANGAN BACA CHAT DARI DIRI SENDIRI (Kecuali Command)
      if (msgRaw.key.fromMe && !msgRaw.message?.conversation?.startsWith('.')) return

      try {
          const m = await Serialize(hisoka, msgRaw)
          if (!m) return 

          const eventFile = await import(`./event/message.js?v=${Date.now()}`)
          await eventFile.default(hisoka, m, message)
          
      } catch (e) {
          // Diamkan error
      }
   })

   return hisoka
}

start()
